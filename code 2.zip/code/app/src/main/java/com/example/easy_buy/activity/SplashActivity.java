package com.example.easy_buy.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.easy_buy.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
    }
}
