package com.example.easy_buy.db;

public class Customer {
    //Varieables for databse
    public static final String TABLE_NAME = "customer";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_CUS_NAME = "cus_name";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_MOBILE_NO = "mobile_no"; //Create filed names
    public static final String COLUMN_PASSWORD = "password";   //Create filed names
  //Create filed names

    public static final String COLUMN_TIMESTAMP = "timestamp";


    private int id;
    private String note;
    private String cus_name;
    private String email;
    private String mobile_no;
    private String password;
    private String address;

    private String timestamp;


    // Create table SQL query
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_CUS_NAME + " TEXT,"                                    //create above files names
                    + COLUMN_EMAIL + " TEXT,"                                    //create above files names
                    + COLUMN_MOBILE_NO + " TEXT,"                                    //create above files names
                    + COLUMN_PASSWORD + " TEXT,"                                    //create above files names
                                                      //create above files names
                    + COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                    + ")";

    public Customer() {
    }

    public Customer(String cus_name, String email, String mobile_no, String password) {
        this.cus_name = cus_name;
        this.email = email;
        this.mobile_no = mobile_no;
        this.password = password;
    }

    public String getNote() {
        return note;
    }

    public Customer(int anInt, String string, String string1) {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getCus_name() {
        return cus_name;
    }

    public void setCus_name(String cus_name) {
        this.cus_name = cus_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile_no() {
        return mobile_no;
    }

    public void setMobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}