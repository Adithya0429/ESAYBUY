package com.example.easy_buy.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "eazybuy_db";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        // create notes table

        db.execSQL(Customer.CREATE_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + Customer.TABLE_NAME);

        // Create tables again
        onCreate(db);
    }

    public Customer loginCutomer(String email) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(Customer.TABLE_NAME,
                new String[]{Customer.COLUMN_ID, Customer.COLUMN_CUS_NAME, Customer.COLUMN_TIMESTAMP},
                Customer.COLUMN_EMAIL + "=?",
                new String[]{String.valueOf(email)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        // prepare note object

        Customer note = new Customer(
                cursor.getInt(cursor.getColumnIndex(Customer.COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(Customer.COLUMN_CUS_NAME)),
                cursor.getString(cursor.getColumnIndex(Customer.COLUMN_TIMESTAMP)));

        // close the db connection
        cursor.close();

        return note;
    }

    public long insertCustomer(String name,String mobile_no,String email, String password) {
        // get writable database as we want to write data
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        // `id` and `timestamp` will be inserted automatically.
        // no need to add them
        values.put(Customer.COLUMN_CUS_NAME, name);
        values.put(Customer.COLUMN_MOBILE_NO, mobile_no);
        values.put(Customer.COLUMN_EMAIL, email);
        values.put(Customer.COLUMN_PASSWORD, password);

        // insert row
        long id = db.insert(Customer.TABLE_NAME, null, values);

        // close db connection
        db.close();

        // return newly inserted row id
        return id;
    }
}
