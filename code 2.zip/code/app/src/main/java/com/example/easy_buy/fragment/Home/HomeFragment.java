package com.example.easy_buy.fragment.Home;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.easy_buy.R;
import com.example.easy_buy.fragment.items.ItemsFragment;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    private CardView card_vegetable;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        initial(view);
        onclick();

        return view;
    }

    private void onclick() {
        card_vegetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    openFrament(new ItemsFragment());
            }
        });
    }

    private void initial(View view) {
        card_vegetable = view.findViewById(R.id.card_vegetable);
    }

    private void openFrament(Fragment fragment) {
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
