package com.example.easy_buy.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.example.easy_buy.R;
import com.example.easy_buy.db.Customer;
import com.example.easy_buy.db.DatabaseHelper;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

/**
 * A simple {@link Fragment} subclass.
 */
public class RegisterFragment extends Fragment {
    private TextView lbl_msg_regi;

    private EditText ed_name;
    private EditText ed_mobile_number;
    private EditText ed_new_email;
    private EditText ed_new_password;
    public RegisterFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        initial(view);
        onclick();

        return view;
    }

    private void onclick() {
        lbl_msg_regi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //LoginFragment loginFragment = new LoginFragment();
                //openFrament(loginFragment);

                String name = ed_name.getText().toString();
                String mobile_no = ed_mobile_number.getText().toString();
                String email = ed_new_email.getText().toString();
                String password = ed_new_password.getText().toString();


               // DatabaseHelper db = new DatabaseHelper(getActivity());
                //long  id = db.insertCustomer(name,mobile_no,email,password);
                //System.out.println(name + mobile_no + email + password);
                writeNewUser(name,email,password,mobile_no);

            }
        });

    }
    private void writeNewUser (String name, String email,String password,String mobile) {

        Customer customer = new Customer(name,email,password,mobile);
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
        String id= mDatabase.push().getKey();
        mDatabase.child("user").child(id).setValue(customer);
    }



    private void initial(View view) {

        lbl_msg_regi = view.findViewById(R.id.lbl_msg);

        ed_name = view.findViewById(R.id.ed_name);
        ed_mobile_number = view.findViewById(R.id.ed_mobile_number);
        ed_new_email = view.findViewById(R.id.ed_new_email);
        ed_new_password = view.findViewById(R.id.ed_new_password);
    }

    private void openFrament(Fragment fragment) {
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
